import { APIRequestContext } from "@playwright/test";

export class ApiHelper
{
    private readonly request: APIRequestContext;
    private readonly baseURL: string;

    constructor(request: APIRequestContext, baseURL: string) 
    {
        this.request = request;
        this.baseURL = baseURL;    
    }

    //Helper methods:

    async get(endPoint: string, headers?: Record< string, string >)
    {
        console.log('Request URL:', `${this.baseURL}${endPoint}`);
        let response = await this.request.get(`${this.baseURL}${endPoint}`, {
            headers: headers
        });

        const body = await response.json();
        console.log(body, response.status());

        return {
            status: response.status(),
            body
        }
    }


    async post(endPoint: string, data: object, headers?: Record< string, string >)
    {
        console.log('Request URL:', `${this.baseURL}${endPoint}`);
        let response = await this.request.post(`${this.baseURL}${endPoint}`, {
            headers: headers,
            data: data
        });

        const body = await response.json();
        console.log(body, response.status());

        return {
            status: response.status(),
            body
        }
    }


    async put(endPoint: string, data: object, headers?: Record< string, string >)
    {
        console.log('Request URL:', `${this.baseURL}${endPoint}`);
        let response = await this.request.put(`${this.baseURL}${endPoint}`, {
            headers: headers,
            data: data
        });

        const body = await response.json();
        console.log(body, response.status());

        return {
            status: response.status(),
            body
        }
    }


    async delete(endPoint: string, headers?: Record< string, string >)
    {
        console.log('Request URL:', `${this.baseURL}${endPoint}`);
        let response = await this.request.delete(`${this.baseURL}${endPoint}`, {
            headers: headers
        });

        console.log(response.status());

        return {
            status: response.status()
        }
    }
}